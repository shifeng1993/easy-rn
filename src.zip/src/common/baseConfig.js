export default baseConfig = {
  baseUrl: 'https://api.shifeng1993.com',
  port: '',
  prefix: ''
}