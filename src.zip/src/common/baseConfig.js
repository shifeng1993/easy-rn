export default baseConfig = {
  baseUrl: 'http://192.168.212.143',
  port: '3333',
  prefix: '/api'
}