import React, {Component} from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  Button,
  StatusBar,
  Platform,
  Dimensions,
  TouchableOpacity
} from 'react-native';

import axios from 'axios'
import http from '../../utils/http'
import FlatList from '../../components/FlatList'
import ListItem from './ListItem.js'

// 常量设置
const ITEM_HEIGHT = 100;
const PAGE_SIZE = 10;
const INITIAL_PAGE = 1;
const CONTENT_HEIGHT = Dimensions
  .get('window')
  .height - 100;
const TO_END = 0.2;

export default class Home extends Component {
  constructor(props) {
    super(props);
    this.state = {
      goodsList: {
        data: [],
        currentPage: INITIAL_PAGE,
        pageSize: PAGE_SIZE
      },
      serachText: null,
      isLoding: true
    }
  }
  render() {
    let style;
    if (Platform.OS === 'ios') {
      style = iosStyles
    } else if (Platform.OS === 'android') {
      style = androidStyles
    }
    return (
      <View style={styles.container}>
        <StatusBar backgroundColor="#cf4218" barStyle="light-content"/>
        <View style={style.statusBar}></View>
        <View style={styles.header}>
          <TextInput
            style={styles.serachText}
            underlineColorAndroid="transparent"
            maxLength={40}
            autoFocus={false}
            onChangeText={(serachText) => this.setState({serachText})}
            value={this.state.serachText}/>
        </View>
        <View style={styles.content}>
          <FlatList
            data={this.state.goodsList.data}
            extraData={this.state}
            renderItem={({item, index}) => (<ListItem key={index} item={item} itemHeight={ITEM_HEIGHT}/>)}
            itemHeight={ITEM_HEIGHT}
            onRefresh={() => {
            this.getGoodsList(1);
          }}
            onEndReachedThreshold={TO_END}
            onEndReached={(info) => {
            if (this.state.isLoding) {
              this.appendGoodsList(info);
            }
          }}
            style={{
            height: CONTENT_HEIGHT
          }}
            hasMore={this._hasMore()}/>
        </View>
      </View>
    )
  }

  getGoodsList(currentPage) {
    let params = {}
    params.currentPage = currentPage;
    params.pageSize = PAGE_SIZE;
    this.setState({isLoding: true})
    http
      .get('/goods/getGoodsList', params)
      .then(res => {
        if (res.status === 200) {
          if (currentPage <= 1) {
            this.setState({goodsList: res.data});
          } else {
            this.setState({
              goodsList: {
                data: this
                  .state
                  .goodsList
                  .data
                  .concat(res.data.data),
                pageTotal: res.data.pageTotal
              },
              isLoding: false
            });
          }
        } else {
          alert(res)
        }
      })
  }
  appendGoodsList(info) {
    console.log(info.distanceFromEnd)
    if (info.distanceFromEnd <= CONTENT_HEIGHT * TO_END) {
      if (this.state.goodsList.data.length === 0) {
        this.getGoodsList(INITIAL_PAGE);
      } else {
        if (this.state.goodsList.pageTotal >= this.state.goodsList.currentPage * this.state.goodsList.pageSize) {
          this.getGoodsList(this.state.goodsList.currentPage + 1);
        } else {
          return
        }
      }
    }
  }
  _hasMore() {
    return this.state.goodsList.pageTotal !== this.state.goodsList.data.length
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // justifyContent: 'center', alignItems: 'center',
    backgroundColor: '#F5FCFF'
  },
  header: {
    padding: 10,
    backgroundColor: '#ff5700',
    marginBottom: 5
  },
  serachText: {
    borderBottomWidth: 1,
    borderColor: '#fff',
    padding: 5,
    color: '#fff',
    fontSize: 16
  },
  content: {
    flex: 1,
    borderTopWidth: 0.5,
    borderColor: '#d9d9d9'
  }
});

const iosStyles = StyleSheet.create({
  statusBar: {
    height: 20,
    backgroundColor: '#cf4218'
  }
});

const androidStyles = StyleSheet.create({
  statusBar: {
    height: 0
  }
});