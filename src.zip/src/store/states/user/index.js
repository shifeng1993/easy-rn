export default {
  // 商品数组
  userinfo : {}
};