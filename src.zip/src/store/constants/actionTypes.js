/* ******** 用户类 *************/
// 设置用户信息
export const SET_USERINFO = 'SET_USERINFO'

// 商品列表动作
export const SET_GOODSLIST = 'SET_GOODSLIST';
export const GET_GOODSLIST = 'GET_GOODSLIST';

// 单个商品动作
export const SET_GOODS = 'SET_GOODS';
export const GET_GOODS = 'GET_GOODS';


